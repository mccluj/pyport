import yaml
import numpy as np
import pandas as pd

from structured_hedger import (
    GBMSimulator,
    HedgingSimulator,
    StructuredProduct,
    plot_error_vs_price,
    plot_payoff_results,
)


def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def run_simulation(sim_config_path):
    config = load_config(sim_config_path)
    config["product"] = load_config(config["product_config"])

    # Pricing
    product = StructuredProduct(config["product"])
    S0_array = np.array([config["S0"]], dtype=float)
    tau = config["product"]["maturity"]
    true_price = product.compute_price(S=S0_array, tau=tau, sigma=config["sigma_true"])[
        0
    ]
    print(f"Structured product fair value: {true_price:.4f}")
    config["initial_cash"] = true_price - config["cash_holdback"]

    # Simulate GBM paths
    simulator = GBMSimulator(
        S0=config["S0"],
        mu=config["mu"],
        sigma=config["sigma_true"],
        T=config["maturity"],
        N=config["N"],
        M=config["M"],
    )
    S_paths = simulator.simulate_paths()

    # Hedging simulation
    hedger = HedgingSimulator(config, S_paths, sigma_hedge=config["sigma_hedge"])
    payoff = hedger.simulate_discrete_hedge()

    # Simple stats
    print(pd.Series(payoff.sim_error).describe(percentiles=[0.05, 0.5, 0.95]))

    # Plot
    plot_payoff_results(payoff)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Structured Product Delta Hedging Simulator"
    )
    parser.add_argument("--config", type=str, required=True)
    args = parser.parse_args()

    run_simulation(args.config)
