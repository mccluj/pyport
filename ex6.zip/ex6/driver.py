import yaml
import numpy as np
import pandas as pd

from structured_hedger import (
    GBMSimulator,
    HedgingSimulator,
    StructuredProduct,
    plot_error_vs_price,
    plot_payoff_results,
)


def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def setup_config(args):
    config = load_config(args.config)
    if args.rehedge_periods is not None:
        config["N"] = args.rehedge_periods
    if args.cash_holdback is not None:
        config["cash_holdback"] = args.cash_holdback
    return config


def run_simulation(args):
    config = setup_config(args)
    config["product"] = load_config(config["product_config"])

    # Pricing
    product = StructuredProduct(config["product"])
    S0_array = np.array([config["S0"]], dtype=float)
    tau = config["product"]["maturity"]
    true_price = product.compute_price(S=S0_array, tau=tau, sigma=config["sigma_true"])[
        0
    ]
    print(f"Structured product fair value: {true_price:.4f}")
    config["initial_cash"] = true_price - config["cash_holdback"]

    # Simulate GBM paths
    simulator = GBMSimulator(
        S0=config["S0"],
        mu=config["mu"],
        sigma=config["sigma_true"],
        T=config["maturity"],
        N=config["N"],
        M=config["M"],
    )
    S_paths = simulator.simulate_paths()

    # Hedging simulation
    hedger = HedgingSimulator(config, S_paths, sigma_hedge=config["sigma_hedge"])
    payoff = hedger.simulate_discrete_hedge()

    # Simple stats
    print(pd.Series(payoff.sim_error).describe(percentiles=[0.05, 0.5, 0.95]))

    # Plot
    plot_payoff_results(payoff, args.plot_file)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Structured Product Delta Hedging Simulator"
    )
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--plot_file", type=str)
    parser.add_argument("--rehedge_periods", type=int)
    parser.add_argument("--cash_holdback", type=float)
    args = parser.parse_args()

    run_simulation(args)
