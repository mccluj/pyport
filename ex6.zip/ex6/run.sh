#!/usr/bin/bash

python driver.py --config sim_config.yaml --rehedge_periods 250 --cash_holdback 0.0 --plot_file max_buffer_250_periods_0.0_holdback.pdf
python driver.py --config sim_config.yaml --rehedge_periods 2500 --cash_holdback 0.0 --plot_file max_buffer_2500_periods_0.0_holdback.pdf
python driver.py --config sim_config.yaml --rehedge_periods 250 --cash_holdback 0.5 --plot_file max_buffer_250_periods_0.5_holdback.pdf
python driver.py --config sim_config.yaml --rehedge_periods 2500 --cash_holdback 0.5 --plot_file max_buffer_2500_periods_0.5_holdback.pdf

