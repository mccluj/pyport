#!/usr/bin/bash

python driver.py --config sim_config.yaml
