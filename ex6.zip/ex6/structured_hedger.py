import numpy as np
from scipy.stats import norm
import yaml
import matplotlib.pyplot as plt
from typing import Optional


class GBMSimulator:
    def __init__(self, S0, mu, sigma, T, N, M):
        self.S0 = S0
        self.mu = mu
        self.sigma = sigma
        self.T = T
        self.N = N
        self.M = M
        self.dt = T / N

    def simulate_paths(self):
        S = np.zeros((self.M, self.N + 1))
        S[:, 0] = self.S0
        for t in range(1, self.N + 1):
            z = np.random.standard_normal(self.M)
            S[:, t] = S[:, t - 1] * np.exp(
                (self.mu - 0.5 * self.sigma**2) * self.dt
                + self.sigma * np.sqrt(self.dt) * z
            )
        return S


class BlackScholes:
    @staticmethod
    def price(S, K, tau, r, sigma, option_type="call"):
        with np.errstate(divide="ignore", invalid="ignore"):
            d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * tau) / (sigma * np.sqrt(tau))
            d2 = d1 - sigma * np.sqrt(tau)
            if option_type == "call":
                return S * norm.cdf(d1) - K * np.exp(-r * tau) * norm.cdf(d2)
            elif option_type == "put":
                return K * np.exp(-r * tau) * norm.cdf(-d2) - S * norm.cdf(-d1)
            else:
                raise ValueError("option_type must be 'call' or 'put'")

    @staticmethod
    def gamma(S, K, tau, r, sigma):
        with np.errstate(divide="ignore", invalid="ignore"):
            d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * tau) / (sigma * np.sqrt(tau))
            return np.nan_to_num(norm.pdf(d1) / (S * sigma * np.sqrt(tau)))

    @staticmethod
    def delta(S, K, tau, r, sigma, option_type="call"):
        with np.errstate(divide="ignore", invalid="ignore"):
            d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * tau) / (sigma * np.sqrt(tau))
            if option_type == "call":
                return norm.cdf(d1)
            elif option_type == "put":
                return norm.cdf(d1) - 1
            else:
                raise ValueError("option_type must be 'call' or 'put'")

    @staticmethod
    def payoff(S, K, option_type="call"):
        if option_type == "call":
            return np.maximum(S - K, 0)
        elif option_type == "put":
            return np.maximum(K - S, 0)
        else:
            raise ValueError("option_type must be 'call' or 'put'")


class StructuredProduct:
    def __init__(self, config):
        self.options = config["options"]
        self.r = config.get("risk_free_rate", 0.01)

    def compute_payoff(self, S_T):
        total = np.zeros_like(S_T)
        for opt in self.options:
            K = opt["strike"]
            w = opt["shares"]
            option_type = opt["type"]
            total += w * BlackScholes.payoff(S_T, K, option_type)
        return total

    def compute_delta(self, S, tau, sigma):
        total = np.zeros_like(S)
        for opt in self.options:
            K = opt["strike"]
            w = opt["shares"]
            option_type = opt["type"]
            total += w * BlackScholes.delta(S, K, tau, self.r, sigma, option_type)
        return total

    def compute_price(self, S, tau, sigma):
        total = np.zeros_like(S, dtype=float)
        for opt in self.options:
            K = opt["strike"]
            w = opt["shares"]
            option_type = opt["type"]
            total += w * BlackScholes.price(S, K, tau, self.r, sigma, option_type)
        return total


class HedgingSimulator:
    def __init__(self, config, S_paths, sigma_hedge):
        self.product = StructuredProduct(config["product"])
        self.S_paths = S_paths
        self.T = config["maturity"]
        self.N = S_paths.shape[1] - 1
        self.dt = self.T / self.N
        self.r = config["risk_free_rate"]
        self.sigma_hedge = sigma_hedge
        self.initial_cash = float(config["initial_cash"])

    def simulate_discrete_hedge(self):
        M = self.S_paths.shape[0]
        S = self.S_paths
        dt = self.dt

        cash = np.full(M, self.initial_cash)
        delta_prev = self.product.compute_delta(S[:, 0], self.T, self.sigma_hedge)
        cash -= delta_prev * S[:, 0]

        for t in range(1, self.N + 1):
            tau = self.T - t * dt
            delta_new = self.product.compute_delta(S[:, t], tau, self.sigma_hedge)
            d_delta = delta_new - delta_prev
            cash *= np.exp(self.r * dt)
            cash -= d_delta * S[:, t]
            delta_prev = delta_new

        final_portfolio = cash + delta_prev * S[:, -1]
        true_payoff = self.product.compute_payoff(S[:, -1])
        return PayoffResults(S[:, -1], true_payoff, final_portfolio)


class PayoffResults:
    def __init__(self, S, true_payoff, sim_payoff):
        self.S = S
        self.true_payoff = true_payoff
        self.sim_payoff = sim_payoff
        self.sim_error = sim_payoff - true_payoff


def plot_error_vs_price(final_prices, errors, title):
    plt.figure(figsize=(10, 6))
    plt.scatter(final_prices, errors, alpha=0.3, s=5)
    plt.axhline(0, color="black", linestyle="--")
    plt.xlabel("Final Stock Price $S_T$")
    plt.ylabel("Hedging Error")
    plt.title(title)
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def plot_payoff_results(payoff: PayoffResults, filename: Optional[str] = None):
    plt.figure(figsize=(10, 10))
    # Add actual payoffs
    plt.subplot(2, 1, 1)
    plt.scatter(payoff.S, payoff.sim_payoff, alpha=0.3, s=5)
    plt.title("Final Payoff")
    plt.grid(True)
    # Add errors with respect to the true payoff
    plt.subplot(2, 1, 2)
    plt.scatter(payoff.S, payoff.sim_error, alpha=0.3, s=5)
    plt.title("Final Payoff Error")
    plt.grid(True)
    # Display
    plt.tight_layout()
    if filename is not None:
        print(f"Plot saved to {filename}")
        plt.savefig(filename)
    else:
        plt.show()
