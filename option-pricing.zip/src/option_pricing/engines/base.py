from __future__ import annotations

from typing import Protocol

from option_pricing.instruments import Option
from option_pricing.market import MarketData
from option_pricing.results import PricingResult


class UnsupportedPricingRequest(ValueError):
    pass


class PricingEngine(Protocol):
    def price(self, option: Option, market: MarketData) -> PricingResult:
        ...
