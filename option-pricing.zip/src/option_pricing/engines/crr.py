from __future__ import annotations

from dataclasses import dataclass
from math import exp, sqrt

from option_pricing.instruments import ExerciseStyle, Option
from option_pricing.market import (
    ContinuousDividendYield,
    DiscreteDividendSchedule,
    Dividend,
    MarketData,
)
from option_pricing.results import PricingResult

from .base import UnsupportedPricingRequest
from .common import intrinsic_value, year_fraction


@dataclass(frozen=True, slots=True)
class CRRConfig:
    steps: int = 500

    def __post_init__(self) -> None:
        if self.steps <= 0:
            raise ValueError("steps must be positive")


class CRREngine:
    name = "crr"

    def __init__(self, config: CRRConfig | None = None) -> None:
        self.config = config or CRRConfig()

    def price(self, option: Option, market: MarketData) -> PricingResult:
        if isinstance(market.dividends, ContinuousDividendYield):
            return self._price_continuous_yield(option, market)
        if isinstance(market.dividends, DiscreteDividendSchedule):
            return self._price_discrete_dividends(option, market)
        raise UnsupportedPricingRequest("unsupported dividend model for CRR")

    def _price_continuous_yield(
        self,
        option: Option,
        market: MarketData,
    ) -> PricingResult:
        t = year_fraction(option, market)
        intrinsic = intrinsic_value(option, market.spot)
        if t == 0.0:
            return PricingResult(intrinsic, self.name, intrinsic, self.config.steps)

        n = self.config.steps
        dt = t / n
        sigma = market.volatility
        r = market.risk_free_rate
        q = market.dividends.yield_rate

        if sigma == 0.0:
            return self._price_zero_vol_continuous(option, market, t, intrinsic)

        u = exp(sigma * sqrt(dt))
        d = 1.0 / u
        growth = exp((r - q) * dt)
        p = (growth - d) / (u - d)
        if not 0.0 <= p <= 1.0:
            raise ValueError(
                "CRR risk-neutral probability is outside [0, 1]; increase steps or review inputs"
            )
        discount = exp(-r * dt)

        values = [0.0] * (n + 1)
        for j in range(n + 1):
            stock = market.spot * (u ** j) * (d ** (n - j))
            values[j] = intrinsic_value(option, stock)

        american = option.exercise_style is ExerciseStyle.AMERICAN
        for step in range(n - 1, -1, -1):
            for j in range(step + 1):
                continuation = discount * (p * values[j + 1] + (1.0 - p) * values[j])
                if american:
                    stock = market.spot * (u ** j) * (d ** (step - j))
                    values[j] = max(continuation, intrinsic_value(option, stock))
                else:
                    values[j] = continuation

        return PricingResult(values[0], self.name, intrinsic, n)

    def _price_discrete_dividends(
        self,
        option: Option,
        market: MarketData,
    ) -> PricingResult:
        """Price using a recombining escrowed-dividend CRR approximation.

        The risky component is spot less the PV of known cash dividends. It is
        evolved on a standard CRR lattice. Remaining dividend PV is then added
        back to each node when evaluating exercise value. Dividend dates are
        aligned to the nearest interior tree step for American exercise checks.
        """
        t = year_fraction(option, market)
        intrinsic = intrinsic_value(option, market.spot)
        if t == 0.0:
            return PricingResult(intrinsic, self.name, intrinsic, self.config.steps)

        n = self.config.steps
        dt = t / n
        sigma = market.volatility
        r = market.risk_free_rate
        active = market.dividends.between(market.valuation_date, option.expiry)
        mapped = self._map_dividends_to_steps(active, market, t, n)
        dividend_pv = sum(
            amount * exp(-r * step * dt)
            for step, amount in mapped.items()
        )
        risky_spot = market.spot - dividend_pv
        if risky_spot <= 0.0:
            raise ValueError(
                "present value of discrete dividends must be less than spot "
                "for the escrowed-dividend CRR approximation"
            )

        remaining_pv = self._remaining_dividend_pv(mapped, r, dt, n)
        diagnostics = {
            "dividend_method": "escrowed",
            "dividend_present_value": dividend_pv,
            "adjusted_spot": risky_spot,
            "mapped_dividend_steps": tuple(sorted(mapped.items())),
        }

        if sigma == 0.0:
            price = self._price_zero_vol_discrete(
                option,
                market,
                t,
                intrinsic,
                risky_spot,
                remaining_pv,
            )
            return PricingResult(price, self.name, intrinsic, n, diagnostics)

        u = exp(sigma * sqrt(dt))
        d = 1.0 / u
        growth = exp(r * dt)
        p = (growth - d) / (u - d)
        if not 0.0 <= p <= 1.0:
            raise ValueError(
                "CRR risk-neutral probability is outside [0, 1]; increase steps or review inputs"
            )
        discount = exp(-r * dt)

        values = [0.0] * (n + 1)
        for j in range(n + 1):
            risky = risky_spot * (u ** j) * (d ** (n - j))
            values[j] = intrinsic_value(option, risky)

        american = option.exercise_style is ExerciseStyle.AMERICAN
        early_exercise_steps: set[int] = set()
        for step in range(n - 1, -1, -1):
            for j in range(step + 1):
                continuation = discount * (p * values[j + 1] + (1.0 - p) * values[j])
                if american:
                    risky = risky_spot * (u ** j) * (d ** (step - j))
                    stock = risky + remaining_pv[step]
                    exercise = intrinsic_value(option, stock)
                    if exercise > continuation:
                        early_exercise_steps.add(step)
                    values[j] = max(continuation, exercise)
                else:
                    values[j] = continuation

        if american:
            diagnostics = dict(diagnostics)
            diagnostics["early_exercise_steps"] = tuple(sorted(early_exercise_steps))

        return PricingResult(values[0], self.name, intrinsic, n, diagnostics)

    @staticmethod
    def _map_dividends_to_steps(
        dividends: tuple[Dividend, ...],
        market: MarketData,
        t: float,
        n: int,
    ) -> dict[int, float]:
        if not dividends:
            return {}
        dt = t / n
        mapped: dict[int, float] = {}
        for dividend in dividends:
            event_t = (dividend.ex_date - market.valuation_date).days / 365.0
            step = int(round(event_t / dt))
            step = max(1, min(n - 1, step))
            mapped[step] = mapped.get(step, 0.0) + dividend.amount
        return mapped

    @staticmethod
    def _remaining_dividend_pv(
        mapped: dict[int, float],
        rate: float,
        dt: float,
        n: int,
    ) -> list[float]:
        result = [0.0] * (n + 1)
        for step in range(n):
            result[step] = sum(
                amount * exp(-rate * (event_step - step) * dt)
                for event_step, amount in mapped.items()
                if event_step >= step
            )
        return result

    def _price_zero_vol_continuous(
        self,
        option: Option,
        market: MarketData,
        t: float,
        intrinsic: float,
    ) -> PricingResult:
        q = market.dividends.yield_rate
        terminal_spot = market.spot * exp((market.risk_free_rate - q) * t)
        terminal_payoff = intrinsic_value(option, terminal_spot)
        european = exp(-market.risk_free_rate * t) * terminal_payoff

        if option.exercise_style is ExerciseStyle.EUROPEAN:
            price = european
        else:
            price = intrinsic
            for step in range(1, self.config.steps + 1):
                tau = t * step / self.config.steps
                spot = market.spot * exp((market.risk_free_rate - q) * tau)
                exercise = intrinsic_value(option, spot) * exp(-market.risk_free_rate * tau)
                price = max(price, exercise)
            price = max(price, european)

        return PricingResult(price, self.name, intrinsic, self.config.steps)

    def _price_zero_vol_discrete(
        self,
        option: Option,
        market: MarketData,
        t: float,
        intrinsic: float,
        risky_spot: float,
        remaining_pv: list[float],
    ) -> float:
        r = market.risk_free_rate
        terminal_stock = risky_spot * exp(r * t)
        european = exp(-r * t) * intrinsic_value(option, terminal_stock)
        if option.exercise_style is ExerciseStyle.EUROPEAN:
            return european

        price = intrinsic
        for step in range(1, self.config.steps):
            tau = t * step / self.config.steps
            risky = risky_spot * exp(r * tau)
            stock = risky + remaining_pv[step]
            exercise_pv = intrinsic_value(option, stock) * exp(-r * tau)
            price = max(price, exercise_pv)
        return max(price, european)
