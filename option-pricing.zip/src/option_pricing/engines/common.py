from __future__ import annotations

from datetime import timedelta

from option_pricing.instruments import Option, OptionType
from option_pricing.market import MarketData


def year_fraction(option: Option, market: MarketData) -> float:
    days = (option.expiry - market.valuation_date).days
    if days < 0:
        raise ValueError("option expiry precedes valuation date")
    return days / 365.0


def intrinsic_value(option: Option, spot: float) -> float:
    if option.option_type is OptionType.CALL:
        return max(spot - option.strike, 0.0)
    return max(option.strike - spot, 0.0)
