from __future__ import annotations

from math import erf, exp, log, sqrt

from option_pricing.instruments import ExerciseStyle, Option, OptionType
from option_pricing.market import (
    ContinuousDividendYield,
    DiscreteDividendSchedule,
    MarketData,
)
from option_pricing.results import PricingResult

from .base import UnsupportedPricingRequest
from .common import intrinsic_value, year_fraction


def _normal_cdf(x: float) -> float:
    return 0.5 * (1.0 + erf(x / sqrt(2.0)))


def _black_scholes_european(
    option: Option,
    spot: float,
    rate: float,
    volatility: float,
    t: float,
    dividend_yield: float,
) -> float:
    if t == 0.0:
        return intrinsic_value(option, spot)

    if volatility == 0.0:
        forward_pv = spot * exp(-dividend_yield * t) - option.strike * exp(-rate * t)
        if option.option_type is OptionType.CALL:
            return max(forward_pv, 0.0)
        return max(-forward_pv, 0.0)

    vol_sqrt_t = volatility * sqrt(t)
    d1 = (
        log(spot / option.strike)
        + (rate - dividend_yield + 0.5 * volatility * volatility) * t
    ) / vol_sqrt_t
    d2 = d1 - vol_sqrt_t

    if option.option_type is OptionType.CALL:
        return (
            spot * exp(-dividend_yield * t) * _normal_cdf(d1)
            - option.strike * exp(-rate * t) * _normal_cdf(d2)
        )
    return (
        option.strike * exp(-rate * t) * _normal_cdf(-d2)
        - spot * exp(-dividend_yield * t) * _normal_cdf(-d1)
    )


class BlackScholesEngine:
    name = "black_scholes"

    def price(self, option: Option, market: MarketData) -> PricingResult:
        if option.exercise_style is not ExerciseStyle.EUROPEAN:
            raise UnsupportedPricingRequest(
                "Black-Scholes engine supports European exercise only"
            )
        if not isinstance(market.dividends, ContinuousDividendYield):
            raise UnsupportedPricingRequest(
                "Black-Scholes engine supports continuous dividend yield only; "
                "use EscrowedDividendBlackScholesEngine for the discrete-dividend approximation"
            )

        t = year_fraction(option, market)
        intrinsic = intrinsic_value(option, market.spot)
        price = _black_scholes_european(
            option=option,
            spot=market.spot,
            rate=market.risk_free_rate,
            volatility=market.volatility,
            t=t,
            dividend_yield=market.dividends.yield_rate,
        )
        return PricingResult(price, self.name, intrinsic)


class EscrowedDividendBlackScholesEngine:
    """European Black-Scholes approximation for known discrete cash dividends.

    The spot input is reduced by the present value of dividends with ex-dates
    strictly between valuation and expiry. This is an approximation, not an
    exact Black-Scholes treatment of fixed cash dividends.
    """

    name = "black_scholes_escrowed_dividend"

    def price(self, option: Option, market: MarketData) -> PricingResult:
        if option.exercise_style is not ExerciseStyle.EUROPEAN:
            raise UnsupportedPricingRequest(
                "Escrowed-dividend Black-Scholes supports European exercise only"
            )
        if not isinstance(market.dividends, DiscreteDividendSchedule):
            raise UnsupportedPricingRequest(
                "Escrowed-dividend Black-Scholes requires a discrete dividend schedule"
            )

        t = year_fraction(option, market)
        intrinsic = intrinsic_value(option, market.spot)
        dividend_pv = market.dividends.present_value(
            market.valuation_date,
            option.expiry,
            market.risk_free_rate,
        )
        adjusted_spot = market.spot - dividend_pv
        if adjusted_spot <= 0.0:
            raise ValueError(
                "present value of discrete dividends must be less than spot "
                "for the escrowed-dividend approximation"
            )

        price = _black_scholes_european(
            option=option,
            spot=adjusted_spot,
            rate=market.risk_free_rate,
            volatility=market.volatility,
            t=t,
            dividend_yield=0.0,
        )
        diagnostics = {
            "dividend_method": "escrowed",
            "dividend_present_value": dividend_pv,
            "adjusted_spot": adjusted_spot,
        }
        return PricingResult(price, self.name, intrinsic, diagnostics=diagnostics)
