from __future__ import annotations

import argparse
from datetime import date

from option_pricing.engines import (
    BlackScholesEngine,
    CRRConfig,
    CRREngine,
    EscrowedDividendBlackScholesEngine,
)
from option_pricing.instruments import ExerciseStyle, Option, OptionType
from option_pricing.market import (
    ContinuousDividendYield,
    DiscreteDividendSchedule,
    Dividend,
    MarketData,
)


def _date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("date must be YYYY-MM-DD") from exc


def _dividend(value: str) -> Dividend:
    try:
        date_text, amount_text = value.split(":", 1)
        return Dividend(date.fromisoformat(date_text), float(amount_text))
    except (ValueError, TypeError) as exc:
        raise argparse.ArgumentTypeError(
            "dividend must be EX_DATE:AMOUNT, for example 2027-03-15:0.25"
        ) from exc


def _add_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--type", choices=[item.value for item in OptionType], required=True)
    parser.add_argument("--spot", type=float, required=True)
    parser.add_argument("--strike", type=float, required=True)
    parser.add_argument("--expiry", type=_date, required=True)
    parser.add_argument("--valuation-date", type=_date, default=date.today())
    parser.add_argument("--rate", type=float, required=True)
    parser.add_argument("--vol", type=float, required=True)

    dividend_group = parser.add_mutually_exclusive_group()
    dividend_group.add_argument(
        "--yield",
        dest="dividend_yield",
        type=float,
        default=None,
        help="continuous dividend yield",
    )
    dividend_group.add_argument(
        "--dividend",
        dest="discrete_dividends",
        type=_dividend,
        action="append",
        help="cash dividend as EX_DATE:AMOUNT; repeat for multiple dividends",
    )


def _build_option(args: argparse.Namespace, style: ExerciseStyle) -> Option:
    return Option(
        option_type=OptionType(args.type),
        exercise_style=style,
        strike=args.strike,
        expiry=args.expiry,
    )


def _build_market(args: argparse.Namespace) -> MarketData:
    if args.discrete_dividends:
        dividends = DiscreteDividendSchedule(tuple(args.discrete_dividends))
    else:
        dividends = ContinuousDividendYield(args.dividend_yield or 0.0)

    return MarketData(
        valuation_date=args.valuation_date,
        spot=args.spot,
        risk_free_rate=args.rate,
        volatility=args.vol,
        dividends=dividends,
    )


def _engine_for_model(model: str, steps: int):
    if model == "bs":
        return BlackScholesEngine()
    if model == "bs-discrete":
        return EscrowedDividendBlackScholesEngine()
    return CRREngine(CRRConfig(steps))


def _price(args: argparse.Namespace) -> int:
    style = ExerciseStyle(args.style)
    option = _build_option(args, style)
    market = _build_market(args)
    engine = _engine_for_model(args.model, args.steps)

    result = engine.price(option, market)
    print(f"model={result.model}")
    print(f"style={style.value}")
    print(f"price={result.price:.10f}")
    print(f"intrinsic={result.intrinsic_value:.10f}")
    if result.steps is not None:
        print(f"steps={result.steps}")
    if result.diagnostics:
        for key, value in result.diagnostics.items():
            print(f"{key}={value}")
    return 0


def _compare(args: argparse.Namespace) -> int:
    option = _build_option(args, ExerciseStyle.EUROPEAN)
    market = _build_market(args)

    if isinstance(market.dividends, DiscreteDividendSchedule):
        baseline = EscrowedDividendBlackScholesEngine().price(option, market)
    else:
        baseline = BlackScholesEngine().price(option, market)
    crr = CRREngine(CRRConfig(args.steps)).price(option, market)

    print("model,style,price,difference_vs_baseline")
    print(f"{baseline.model},european,{baseline.price:.10f},{0.0:.10f}")
    print(f"{crr.model},european,{crr.price:.10f},{crr.price - baseline.price:.10f}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="option-price")
    subparsers = parser.add_subparsers(dest="command", required=True)

    price_parser = subparsers.add_parser("price", help="Price one option")
    _add_common_arguments(price_parser)
    price_parser.add_argument(
        "--model",
        choices=["bs", "bs-discrete", "crr"],
        required=True,
    )
    price_parser.add_argument(
        "--style",
        choices=[item.value for item in ExerciseStyle],
        required=True,
    )
    price_parser.add_argument("--steps", type=int, default=500)
    price_parser.set_defaults(func=_price)

    compare_parser = subparsers.add_parser(
        "compare", help="Compare European Black-Scholes-style baseline and CRR"
    )
    _add_common_arguments(compare_parser)
    compare_parser.add_argument("--steps", type=int, default=500)
    compare_parser.set_defaults(func=_compare)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
