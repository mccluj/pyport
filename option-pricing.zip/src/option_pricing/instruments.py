from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum


class OptionType(str, Enum):
    CALL = "call"
    PUT = "put"


class ExerciseStyle(str, Enum):
    EUROPEAN = "european"
    AMERICAN = "american"


@dataclass(frozen=True, slots=True)
class Option:
    option_type: OptionType
    exercise_style: ExerciseStyle
    strike: float
    expiry: date

    def __post_init__(self) -> None:
        if self.strike <= 0.0:
            raise ValueError("strike must be positive")
