from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class PricingResult:
    price: float
    model: str
    intrinsic_value: float
    steps: int | None = None
    diagnostics: Mapping[str, Any] | None = None
