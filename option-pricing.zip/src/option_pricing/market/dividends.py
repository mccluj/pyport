from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from math import exp
from typing import Protocol, runtime_checkable


@runtime_checkable
class DividendModel(Protocol):
    """Marker protocol for dividend representations consumed by pricing engines."""


@dataclass(frozen=True, slots=True)
class ContinuousDividendYield:
    yield_rate: float = 0.0


@dataclass(frozen=True, slots=True, order=True)
class Dividend:
    ex_date: date
    amount: float

    def __post_init__(self) -> None:
        if self.amount < 0.0:
            raise ValueError("dividend amount cannot be negative")


@dataclass(frozen=True, slots=True)
class DiscreteDividendSchedule:
    dividends: tuple[Dividend, ...]

    def __post_init__(self) -> None:
        ordered = tuple(sorted(self.dividends, key=lambda item: item.ex_date))
        if ordered != self.dividends:
            object.__setattr__(self, "dividends", ordered)

    def between(self, start: date, end: date) -> tuple[Dividend, ...]:
        """Return ex-dividend events strictly after start and strictly before end."""
        return tuple(
            dividend
            for dividend in self.dividends
            if start < dividend.ex_date < end
        )

    def present_value(self, valuation_date: date, expiry: date, rate: float) -> float:
        """Present value of dividends in the option pricing horizon."""
        total = 0.0
        for dividend in self.between(valuation_date, expiry):
            t = (dividend.ex_date - valuation_date).days / 365.0
            total += dividend.amount * exp(-rate * t)
        return total
