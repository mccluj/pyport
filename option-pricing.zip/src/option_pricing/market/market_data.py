from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from .dividends import ContinuousDividendYield, DividendModel


@dataclass(frozen=True, slots=True)
class MarketData:
    valuation_date: date
    spot: float
    risk_free_rate: float
    volatility: float
    dividends: DividendModel = ContinuousDividendYield()

    def __post_init__(self) -> None:
        if self.spot <= 0.0:
            raise ValueError("spot must be positive")
        if self.volatility < 0.0:
            raise ValueError("volatility cannot be negative")
