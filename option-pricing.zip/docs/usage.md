# Usage guide

The examples directory is the executable usage guide for the Python API. Each
script is intentionally small and can be run directly after creating the
virtual environment.

## Continuous-yield examples

```text
python examples/01_black_scholes_european.py
python examples/02_crr_european.py
python examples/03_compare_bs_crr.py
```

These demonstrate analytic Black-Scholes, CRR, and a European comparison under
a continuous dividend yield.

## Discrete cash dividends

American CRR with a model-independent dividend schedule:

```text
python examples/04_crr_discrete_dividends.py
```

European Black-Scholes using the explicitly named escrowed-dividend
approximation:

```text
python examples/05_black_scholes_discrete_approximation.py
```

The discrete schedule is represented independently of the pricing engine:

```python
from datetime import date
from option_pricing.market import DiscreteDividendSchedule, Dividend

schedule = DiscreteDividendSchedule(
    (
        Dividend(date(2026, 3, 15), 0.25),
        Dividend(date(2026, 6, 15), 0.25),
    )
)
```

## Command-line interface

Continuous dividend yield:

```text
option-price price --model crr --type call --style american --spot 100 --strike 100 --valuation-date 2026-01-01 --expiry 2027-01-01 --rate 0.05 --vol 0.20 --yield 0.01 --steps 1000
```

Discrete dividends can be repeated on the command line:

```text
option-price price --model crr --type call --style american --spot 100 --strike 100 --valuation-date 2026-01-01 --expiry 2027-01-01 --rate 0.05 --vol 0.20 --dividend 2026-03-15:0.25 --dividend 2026-06-15:0.25 --steps 1000
```

For the European escrowed-dividend Black-Scholes approximation, use:

```text
option-price price --model bs-discrete --type call --style european --spot 100 --strike 100 --valuation-date 2026-01-01 --expiry 2027-01-01 --rate 0.05 --vol 0.20 --dividend 2026-03-15:0.25 --dividend 2026-06-15:0.25
```

The `compare` command selects the ordinary Black-Scholes baseline for a
continuous yield and the escrowed-dividend Black-Scholes approximation for a
discrete schedule.
