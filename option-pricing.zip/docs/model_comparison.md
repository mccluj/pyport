# Pricing model comparison guide

This document describes package capabilities. Research conclusions belong in
the `experiments/` tree rather than here.

| Capability | Black-Scholes | Escrowed-dividend Black-Scholes | CRR | Event-date backward induction |
| --- | --- | --- | --- | --- |
| European call/put | Yes | Yes | Yes | Future |
| American call/put | No | No | Yes | Future |
| Continuous dividend yield | Yes | No | Yes | Future decision |
| Fixed discrete cash dividends | No | Approximation | Escrowed-dividend CRR approximation | Future |
| Numerical time steps | No | No | Yes | Event dates plus numerical representation |
| Early-exercise diagnostics | No | No | Basic diagnostics | Future |

## Black-Scholes

`BlackScholesEngine` is analytic Black-Scholes for European calls and puts with
a continuous dividend yield. It deliberately rejects a discrete dividend
schedule.

## Escrowed-dividend Black-Scholes

`EscrowedDividendBlackScholesEngine` is explicitly an approximation. It reduces
spot by the present value of known fixed cash dividends with ex-dates strictly
between valuation and expiry, then applies European Black-Scholes with zero
continuous yield.

Keeping this as a separate engine prevents a fixed-cash-dividend approximation
from being mistaken for ordinary Black-Scholes.

## CRR

`CRREngine` supports European and American exercise with either a continuous
dividend yield or a fixed discrete cash-dividend schedule.

For discrete dividends, version 0.2 uses a recombining escrowed-dividend
approximation. The risky component is spot less the present value of remaining
cash dividends. That component evolves on the CRR lattice; remaining dividend
PV is added back when intrinsic value is evaluated. Ex-dividend dates are
aligned to interior tree steps for American exercise checks.

This preserves a recombining tree and makes the numerical convention explicit.
It is not intended to preclude a later event-date engine with different
numerical treatment.

## Future event-date backward-induction engine

A later engine may work backward over ex-dividend dates, use Black-Scholes
risk-neutral transition dynamics between event dates, and compare continuation
with exercise immediately before ex-dividend events for American options. It
will consume the same `Option`, `MarketData`, and `DiscreteDividendSchedule`
objects as the current engines.
