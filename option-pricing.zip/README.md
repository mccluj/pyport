# option-pricing

Research-oriented option-pricing library with a CLI.

Current package scope in version 0.2.1:

- European Black-Scholes pricing with continuous dividend yield.
- European and American Cox-Ross-Rubinstein (CRR) pricing with continuous dividend yield.
- Model-independent fixed cash-dividend schedules.
- European escrowed-dividend Black-Scholes approximation for discrete cash dividends.
- European and American CRR using an explicit recombining escrowed-dividend approximation.
- CLI commands for single-model pricing and European model comparison.
- Executable usage examples and a separate research-experiment area.

The architecture intentionally does not assume that discrete dividends imply
CRR. A future event-date backward-induction engine can consume the same
`Option`, `MarketData`, and `DiscreteDividendSchedule` objects.

## Install for development

From Git Bash, macOS, or Linux:

```text
./scripts/create_venv.sh
```

The script creates a repository-local `.venv`, upgrades `pip`, explicitly
installs `pytest`, and installs the package in editable mode.

Manual equivalent:

```text
python -m venv .venv
. .venv/Scripts/activate                  # Windows Git Bash
python -m pip install --upgrade pip
python -m pip install "pytest>=9.0"
python -m pip install -e .
```

On macOS/Linux, activate with `. .venv/bin/activate` instead.

## Python API examples

```text
python examples/01_black_scholes_european.py
python examples/02_crr_european.py
python examples/03_compare_bs_crr.py
python examples/04_crr_discrete_dividends.py
python examples/05_black_scholes_discrete_approximation.py
```

See `docs/usage.md` for details.

## CLI

Continuous-yield European call with Black-Scholes:

```text
option-price price --model bs --type call --style european --spot 100 --strike 100 --valuation-date 2026-01-01 --expiry 2027-01-01 --rate 0.05 --vol 0.20 --yield 0.01
```

American call with discrete cash dividends using CRR:

```text
option-price price --model crr --type call --style american --spot 100 --strike 100 --valuation-date 2026-01-01 --expiry 2027-01-01 --rate 0.05 --vol 0.20 --dividend 2026-03-15:0.25 --dividend 2026-06-15:0.25 --steps 1000
```

European escrowed-dividend Black-Scholes approximation:

```text
option-price price --model bs-discrete --type call --style european --spot 100 --strike 100 --valuation-date 2026-01-01 --expiry 2027-01-01 --rate 0.05 --vol 0.20 --dividend 2026-03-15:0.25 --dividend 2026-06-15:0.25
```

## Research experiments

The `experiments/` directory remains separate from package implementation.
The primary deep-ITM call experiment is now:

```text
python experiments/deep_itm_call/deep_itm_call.py
```

It compares the current continuous-yield and quarterly-cash-dividend pricing
capabilities without adding research logic to the installed package.

## Tests

```text
python -m pytest
```
