#!/usr/bin/env bash

# This script must be executed, not sourced. Sourcing a setup script that uses
# shell error handling can unexpectedly alter or terminate the caller's shell.
if [[ "${BASH_SOURCE[0]}" != "$0" ]]; then
    echo "Error: execute this script; do not source it." >&2
    echo "Run: ./scripts/create_venv.sh" >&2
    return 1
fi

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VENV_DIR="${REPO_ROOT}/.venv"

select_python() {
    if command -v python3.12 >/dev/null 2>&1; then
        PYTHON_CMD=(python3.12)
        return
    fi

    if command -v py >/dev/null 2>&1; then
        PYTHON_CMD=(py -3.12)
        return
    fi

    if command -v python3 >/dev/null 2>&1; then
        PYTHON_CMD=(python3)
        return
    fi

    if command -v python >/dev/null 2>&1; then
        PYTHON_CMD=(python)
        return
    fi

    echo "Error: Python 3.12 or later was not found on PATH." >&2
    exit 1
}

select_python

"${PYTHON_CMD[@]}" - <<'PY'
import sys

if sys.version_info < (3, 12):
    version = ".".join(str(part) for part in sys.version_info[:3])
    raise SystemExit(
        f"Error: Python 3.12 or later is required; found Python {version}."
    )
PY

if [[ ! -d "${VENV_DIR}" ]]; then
    echo "Creating virtual environment at ${VENV_DIR}"
    "${PYTHON_CMD[@]}" -m venv "${VENV_DIR}"
else
    echo "Using existing virtual environment at ${VENV_DIR}"
fi

if [[ -x "${VENV_DIR}/Scripts/python.exe" ]]; then
    VENV_PYTHON="${VENV_DIR}/Scripts/python.exe"
elif [[ -x "${VENV_DIR}/bin/python" ]]; then
    VENV_PYTHON="${VENV_DIR}/bin/python"
else
    echo "Error: Could not locate the virtual environment Python executable." >&2
    exit 1
fi

"${VENV_PYTHON}" -m pip install --upgrade pip

# Install from the repository working directory rather than passing an MSYS
# /c/... path to Windows pip. This works in Git Bash and on macOS/Linux.
cd "${REPO_ROOT}"
"${VENV_PYTHON}" -m pip install "pytest>=9.0"
"${VENV_PYTHON}" -m pip install -e .

echo
echo "Virtual environment is ready."
echo "Python: $("${VENV_PYTHON}" --version)"
echo "Run tests with:"
echo "  ${VENV_PYTHON} -m pytest"
echo
echo "To activate it in Git Bash:"
if [[ -f "${VENV_DIR}/Scripts/activate" ]]; then
    echo "  . .venv/Scripts/activate"
else
    echo "  . .venv/bin/activate"
fi
