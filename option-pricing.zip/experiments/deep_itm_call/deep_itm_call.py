from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import TextIO

from option_pricing import (
    ContinuousDividendYield,
    ExerciseStyle,
    MarketData,
    Option,
    OptionType,
)
from option_pricing.engines import (
    BlackScholesEngine,
    CRRConfig,
    CRREngine,
    EscrowedDividendBlackScholesEngine,
)
from option_pricing.market import DiscreteDividendSchedule, Dividend


@dataclass(frozen=True, slots=True)
class DeepItmCallScenario:
    valuation_date: date = date(2026, 9, 18)
    expiry: date = date(2027, 9, 18)
    spot: float = 100.0
    strike: float = 1.0
    risk_free_rate: float = 0.05
    volatility: float = 0.20
    dividend_yield: float = 0.01
    cash_dividend_amount: float = 0.25
    cash_dividend_dates: tuple[date, ...] = (
        date(2026, 12, 15),
        date(2027, 3, 15),
        date(2027, 6, 15),
        date(2027, 9, 15),
    )
    crr_steps: int = 2000

    def discrete_schedule(self) -> DiscreteDividendSchedule:
        return DiscreteDividendSchedule(
            tuple(
                Dividend(ex_date, self.cash_dividend_amount)
                for ex_date in self.cash_dividend_dates
            )
        )


def _options(scenario: DeepItmCallScenario) -> tuple[Option, Option]:
    european = Option(
        option_type=OptionType.CALL,
        exercise_style=ExerciseStyle.EUROPEAN,
        strike=scenario.strike,
        expiry=scenario.expiry,
    )
    american = Option(
        option_type=OptionType.CALL,
        exercise_style=ExerciseStyle.AMERICAN,
        strike=scenario.strike,
        expiry=scenario.expiry,
    )
    return european, american


def build_rows(
    scenario: DeepItmCallScenario,
) -> list[dict[str, float | int | str]]:
    european, american = _options(scenario)
    crr = CRREngine(CRRConfig(steps=scenario.crr_steps))

    continuous_market = MarketData(
        valuation_date=scenario.valuation_date,
        spot=scenario.spot,
        risk_free_rate=scenario.risk_free_rate,
        volatility=scenario.volatility,
        dividends=ContinuousDividendYield(scenario.dividend_yield),
    )
    continuous_bs = BlackScholesEngine().price(european, continuous_market)
    continuous_european = crr.price(european, continuous_market)
    continuous_american = crr.price(american, continuous_market)

    discrete_market = MarketData(
        valuation_date=scenario.valuation_date,
        spot=scenario.spot,
        risk_free_rate=scenario.risk_free_rate,
        volatility=scenario.volatility,
        dividends=scenario.discrete_schedule(),
    )
    discrete_bs = EscrowedDividendBlackScholesEngine().price(
        european,
        discrete_market,
    )
    discrete_european = crr.price(european, discrete_market)
    discrete_american = crr.price(american, discrete_market)

    discrete_exercise_steps = ()
    if discrete_american.diagnostics is not None:
        discrete_exercise_steps = discrete_american.diagnostics.get(
            "early_exercise_steps",
            (),
        )

    return [
        {
            "dividend_case": "continuous_yield",
            "model": "black_scholes",
            "style": "european",
            "steps": 0,
            "price": continuous_bs.price,
            "american_premium": 0.0,
            "exercise_detail": "not_applicable",
        },
        {
            "dividend_case": "continuous_yield",
            "model": "crr",
            "style": "european",
            "steps": scenario.crr_steps,
            "price": continuous_european.price,
            "american_premium": 0.0,
            "exercise_detail": "not_applicable",
        },
        {
            "dividend_case": "continuous_yield",
            "model": "crr",
            "style": "american",
            "steps": scenario.crr_steps,
            "price": continuous_american.price,
            "american_premium": continuous_american.price
            - continuous_european.price,
            "exercise_detail": "american_exercise_checked_each_step",
        },
        {
            "dividend_case": "quarterly_cash",
            "model": "black_scholes_escrowed_dividend",
            "style": "european",
            "steps": 0,
            "price": discrete_bs.price,
            "american_premium": 0.0,
            "exercise_detail": "not_applicable",
        },
        {
            "dividend_case": "quarterly_cash",
            "model": "crr_escrowed_dividend",
            "style": "european",
            "steps": scenario.crr_steps,
            "price": discrete_european.price,
            "american_premium": 0.0,
            "exercise_detail": "not_applicable",
        },
        {
            "dividend_case": "quarterly_cash",
            "model": "crr_escrowed_dividend",
            "style": "american",
            "steps": scenario.crr_steps,
            "price": discrete_american.price,
            "american_premium": discrete_american.price - discrete_european.price,
            "exercise_detail": ";".join(str(step) for step in discrete_exercise_steps),
        },
    ]


def write_csv(
    rows: list[dict[str, float | int | str]],
    stream: TextIO,
) -> None:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)


def print_report(
    scenario: DeepItmCallScenario,
    rows: list[dict[str, float | int | str]],
) -> None:
    print("Deep-ITM call experiment")
    print("========================")
    print(f"valuation date:  {scenario.valuation_date}")
    print(f"expiry:          {scenario.expiry}")
    print(f"spot:            {scenario.spot:.6f}")
    print(f"strike:          {scenario.strike:.6f}")
    print(f"intrinsic value: {scenario.spot - scenario.strike:.6f}")
    print(f"risk-free rate:  {scenario.risk_free_rate:.4%}")
    print(f"volatility:      {scenario.volatility:.4%}")
    print(f"yield case:      {scenario.dividend_yield:.4%}")
    print(
        "cash case:       "
        f"{len(scenario.cash_dividend_dates)} x "
        f"{scenario.cash_dividend_amount:.6f}"
    )
    print(f"CRR steps:       {scenario.crr_steps}")
    print()
    print(
        f"{'dividend case':<18} {'model':<34} {'style':<10} "
        f"{'price':>14} {'American premium':>18}"
    )
    print("-" * 100)
    for row in rows:
        print(
            f"{str(row['dividend_case']):<18} "
            f"{str(row['model']):<34} "
            f"{str(row['style']):<10} "
            f"{float(row['price']):>14.8f} "
            f"{float(row['american_premium']):>18.8f}"
        )

    print()
    print("Discrete-dividend CRR exercise steps:")
    discrete_american = next(
        row
        for row in rows
        if row["dividend_case"] == "quarterly_cash"
        and row["style"] == "american"
    )
    detail = str(discrete_american["exercise_detail"])
    print(detail if detail else "none")


def _build_scenario(args: argparse.Namespace) -> DeepItmCallScenario:
    return DeepItmCallScenario(
        spot=args.spot,
        strike=args.strike,
        risk_free_rate=args.rate,
        volatility=args.volatility,
        dividend_yield=args.dividend_yield,
        cash_dividend_amount=args.cash_dividend,
        crr_steps=args.steps,
    )


def main() -> None:
    defaults = DeepItmCallScenario()
    parser = argparse.ArgumentParser(
        description="Compare European and American values for a deep-ITM call."
    )
    parser.add_argument("--spot", type=float, default=defaults.spot)
    parser.add_argument("--strike", type=float, default=defaults.strike)
    parser.add_argument("--rate", type=float, default=defaults.risk_free_rate)
    parser.add_argument("--volatility", type=float, default=defaults.volatility)
    parser.add_argument(
        "--dividend-yield",
        type=float,
        default=defaults.dividend_yield,
    )
    parser.add_argument(
        "--cash-dividend",
        type=float,
        default=defaults.cash_dividend_amount,
        help="Amount of each of the four default quarterly cash dividends.",
    )
    parser.add_argument("--steps", type=int, default=defaults.crr_steps)
    parser.add_argument(
        "--output",
        type=Path,
        help="Optional CSV output path. A readable report is printed by default.",
    )
    args = parser.parse_args()

    scenario = _build_scenario(args)
    rows = build_rows(scenario)
    if args.output is None:
        print_report(scenario, rows)
        return

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="ascii") as stream:
        write_csv(rows, stream)
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
