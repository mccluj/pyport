import argparse
import csv
from datetime import date
from pathlib import Path
from typing import TextIO

from option_pricing import (
    ContinuousDividendYield,
    ExerciseStyle,
    MarketData,
    Option,
    OptionType,
)
from option_pricing.engines import BlackScholesEngine, CRRConfig, CRREngine


VOLATILITIES = (0.10, 0.20, 0.30, 0.40)
STEPS = (100, 250, 500, 1000, 2000)


def build_rows() -> list[dict[str, float | int | str]]:
    rows: list[dict[str, float | int | str]] = []
    valuation_date = date(2026, 9, 18)
    expiry = date(2027, 9, 18)

    for volatility in VOLATILITIES:
        market = MarketData(
            valuation_date=valuation_date,
            spot=100.0,
            risk_free_rate=0.05,
            volatility=volatility,
            dividends=ContinuousDividendYield(0.01),
        )
        european = Option(
            option_type=OptionType.CALL,
            exercise_style=ExerciseStyle.EUROPEAN,
            strike=1.0,
            expiry=expiry,
        )
        american = Option(
            option_type=OptionType.CALL,
            exercise_style=ExerciseStyle.AMERICAN,
            strike=1.0,
            expiry=expiry,
        )

        bs_price = BlackScholesEngine().price(european, market).price
        rows.append(
            {
                "volatility": volatility,
                "style": "european",
                "model": "black_scholes",
                "steps": 0,
                "price": bs_price,
                "american_premium_vs_crr_european": 0.0,
            }
        )

        for steps in STEPS:
            engine = CRREngine(CRRConfig(steps=steps))
            european_price = engine.price(european, market).price
            american_price = engine.price(american, market).price
            rows.append(
                {
                    "volatility": volatility,
                    "style": "european",
                    "model": "crr",
                    "steps": steps,
                    "price": european_price,
                    "american_premium_vs_crr_european": 0.0,
                }
            )
            rows.append(
                {
                    "volatility": volatility,
                    "style": "american",
                    "model": "crr",
                    "steps": steps,
                    "price": american_price,
                    "american_premium_vs_crr_european": american_price
                    - european_price,
                }
            )
    return rows


def write_csv(rows: list[dict[str, float | int | str]], stream: TextIO) -> None:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Baseline deep-ITM call experiment with a continuous yield."
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Optional CSV output path. Prints CSV to stdout when omitted.",
    )
    args = parser.parse_args()

    rows = build_rows()
    if args.output is None:
        import sys

        write_csv(rows, sys.stdout)
        return

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="ascii") as stream:
        write_csv(rows, stream)
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
