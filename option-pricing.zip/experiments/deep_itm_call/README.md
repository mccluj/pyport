# Deep-ITM call experiment

This experiment addresses the question that motivated the library: how much
value can American exercise add to a very deep-in-the-money call when the
underlying pays dividends?

The default problem is deliberately simple and visible in one scenario object:

```text
valuation date       2026-09-18
expiry               2027-09-18
spot                  100
strike                  1
risk-free rate          5%
volatility             20%
CRR steps             2000
```

It compares two dividend descriptions:

```text
continuous yield       1% per year
quarterly cash          0.25 on each of four ex-dividend dates
```

The two dividend descriptions are economically similar in scale, but they are
not asserted to be exactly equivalent. The point of the experiment is to make
the pricing and exercise consequences visible.

## Run the primary experiment

```text
python experiments/deep_itm_call/deep_itm_call.py
```

The report includes:

- analytic Black-Scholes European value for the continuous-yield case;
- CRR European and American values for the continuous-yield case;
- escrowed-dividend Black-Scholes European approximation for the cash-dividend
  case;
- escrowed-dividend CRR European and American values for the cash-dividend
  case;
- American-minus-European premium within each CRR dividend case;
- CRR tree steps at which early exercise is identified for the discrete case.

The current discrete-dividend methods are explicitly approximations. This
experiment should therefore be treated as a reproducible model comparison, not
as an external market-price benchmark.

## Save the rows as CSV

```text
python experiments/deep_itm_call/deep_itm_call.py --output experiments/deep_itm_call/results/deep_itm_call.csv
```

## Adjust the basic problem

The script already exposes a small set of parameters so the experiment can be
perturbed without editing package code:

```text
--spot
--strike
--rate
--volatility
--dividend-yield
--cash-dividend
--steps
```

For example:

```text
python experiments/deep_itm_call/deep_itm_call.py --strike 2 --cash-dividend 0.30 --steps 4000
```

Dates and richer dividend schedules remain in `DeepItmCallScenario` for now.
If the investigation expands, the scenario can be extended without changing
the pricing-engine interfaces.

## Earlier baseline

`continuous_yield.py` remains as the original volatility/tree-size sweep. It is
useful for studying numerical stability independently of this focused
comparison.

## Likely future extensions

1. Allow arbitrary ex-dividend schedules from the command line or a config
   file.
2. Sweep strike, dividend size, rates, and volatility.
3. Convert mapped CRR exercise steps back to calendar dates in the report.
4. Add plots and generated result tables outside the installed package.
5. Add the future event-date backward-induction engine as another comparison
   method without changing the scenario definition.
