import argparse
import csv
from datetime import date
from pathlib import Path
from typing import TextIO

from option_pricing import (
    ContinuousDividendYield,
    ExerciseStyle,
    MarketData,
    Option,
    OptionType,
)
from option_pricing.engines import BlackScholesEngine, CRRConfig, CRREngine


DEFAULT_STEPS = (10, 25, 50, 100, 250, 500, 1000, 2000)


def build_rows() -> list[dict[str, float | int]]:
    option = Option(
        option_type=OptionType.CALL,
        exercise_style=ExerciseStyle.EUROPEAN,
        strike=100.0,
        expiry=date(2027, 9, 18),
    )
    market = MarketData(
        valuation_date=date(2026, 9, 18),
        spot=100.0,
        risk_free_rate=0.05,
        volatility=0.20,
        dividends=ContinuousDividendYield(0.01),
    )

    bs_price = BlackScholesEngine().price(option, market).price
    rows: list[dict[str, float | int]] = []
    for steps in DEFAULT_STEPS:
        crr_price = CRREngine(CRRConfig(steps=steps)).price(option, market).price
        rows.append(
            {
                "steps": steps,
                "bs_price": bs_price,
                "crr_price": crr_price,
                "difference": crr_price - bs_price,
                "absolute_error": abs(crr_price - bs_price),
            }
        )
    return rows


def write_csv(rows: list[dict[str, float | int]], stream: TextIO) -> None:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare CRR convergence against Black-Scholes."
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Optional CSV output path. Prints CSV to stdout when omitted.",
    )
    args = parser.parse_args()

    rows = build_rows()
    if args.output is None:
        import sys

        write_csv(rows, sys.stdout)
        return

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="ascii") as stream:
        write_csv(rows, stream)
    print(f"Wrote {args.output}")


if __name__ == "__main__":
    main()
