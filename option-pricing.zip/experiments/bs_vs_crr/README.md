# Black-Scholes vs CRR convergence

This experiment establishes a baseline before discrete-dividend support is added.
It prices the same one-year European call with analytic Black-Scholes and CRR
using increasing tree sizes.

Run:

```text
python experiments/bs_vs_crr/convergence.py
```

To save the data:

```text
python experiments/bs_vs_crr/convergence.py --output experiments/bs_vs_crr/results/convergence.csv
```

The important quantities are the signed CRR minus Black-Scholes difference and
the absolute error. CRR convergence is not expected to be monotonic at every
successive tree size, so this file is intended for inspection rather than as a
replacement for unit tests.
