from datetime import date

import pytest

from option_pricing.engines import BlackScholesEngine, UnsupportedPricingRequest
from option_pricing.instruments import ExerciseStyle, Option, OptionType
from option_pricing.market import (
    ContinuousDividendYield,
    DiscreteDividendSchedule,
    Dividend,
    MarketData,
)


def test_black_scholes_known_call_value() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    market = MarketData(
        date(2026, 1, 1),
        100.0,
        0.05,
        0.20,
        ContinuousDividendYield(0.0),
    )
    result = BlackScholesEngine().price(option, market)
    assert result.price == pytest.approx(10.4505835722, abs=1e-9)


def test_black_scholes_put_call_parity_with_yield() -> None:
    expiry = date(2027, 1, 1)
    market = MarketData(
        date(2026, 1, 1),
        100.0,
        0.05,
        0.20,
        ContinuousDividendYield(0.02),
    )
    engine = BlackScholesEngine()
    call = engine.price(Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, expiry), market)
    put = engine.price(Option(OptionType.PUT, ExerciseStyle.EUROPEAN, 100.0, expiry), market)

    from math import exp

    rhs = 100.0 * exp(-0.02) - 100.0 * exp(-0.05)
    assert call.price - put.price == pytest.approx(rhs, abs=1e-10)


def test_black_scholes_rejects_american() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.AMERICAN, 100.0, date(2027, 1, 1))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20)
    with pytest.raises(UnsupportedPricingRequest):
        BlackScholesEngine().price(option, market)


def test_black_scholes_rejects_discrete_dividends_for_now() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    schedule = DiscreteDividendSchedule((Dividend(date(2026, 6, 1), 1.0),))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, schedule)
    with pytest.raises(UnsupportedPricingRequest):
        BlackScholesEngine().price(option, market)
