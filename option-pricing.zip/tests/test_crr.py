from datetime import date

import pytest

from option_pricing.engines import BlackScholesEngine, CRRConfig, CRREngine
from option_pricing.instruments import ExerciseStyle, Option, OptionType
from option_pricing.market import (
    ContinuousDividendYield,
    DiscreteDividendSchedule,
    Dividend,
    MarketData,
)


def test_crr_european_call_converges_to_black_scholes() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    market = MarketData(
        date(2026, 1, 1),
        100.0,
        0.05,
        0.20,
        ContinuousDividendYield(0.02),
    )
    bs = BlackScholesEngine().price(option, market).price
    crr = CRREngine(CRRConfig(2000)).price(option, market).price
    assert crr == pytest.approx(bs, abs=0.002)


def test_american_put_is_not_less_than_european_put() -> None:
    market = MarketData(date(2026, 1, 1), 80.0, 0.05, 0.25)
    european = Option(OptionType.PUT, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    american = Option(OptionType.PUT, ExerciseStyle.AMERICAN, 100.0, date(2027, 1, 1))
    engine = CRREngine(CRRConfig(1000))
    assert engine.price(american, market).price >= engine.price(european, market).price


def test_non_dividend_american_call_matches_european_call() -> None:
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20)
    european = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    american = Option(OptionType.CALL, ExerciseStyle.AMERICAN, 100.0, date(2027, 1, 1))
    engine = CRREngine(CRRConfig(1000))
    assert engine.price(american, market).price == pytest.approx(
        engine.price(european, market).price,
        abs=1e-10,
    )


def test_crr_supports_discrete_dividends() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.AMERICAN, 100.0, date(2027, 1, 1))
    schedule = DiscreteDividendSchedule((Dividend(date(2026, 6, 1), 1.0),))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, schedule)
    result = CRREngine(CRRConfig(500)).price(option, market)
    assert result.price >= 0.0
    assert result.diagnostics is not None
    assert result.diagnostics["dividend_method"] == "escrowed"
