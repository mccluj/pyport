from datetime import date

import pytest

from option_pricing.market import DiscreteDividendSchedule, Dividend


def test_discrete_dividends_are_sorted_by_ex_date() -> None:
    later = Dividend(date(2026, 9, 1), 0.25)
    earlier = Dividend(date(2026, 6, 1), 0.25)
    schedule = DiscreteDividendSchedule((later, earlier))
    assert schedule.dividends == (earlier, later)


def test_discrete_dividend_schedule_filters_pricing_horizon() -> None:
    schedule = DiscreteDividendSchedule(
        (
            Dividend(date(2025, 12, 1), 0.25),
            Dividend(date(2026, 3, 1), 0.25),
            Dividend(date(2027, 1, 1), 0.25),
        )
    )
    assert schedule.between(date(2026, 1, 1), date(2027, 1, 1)) == (
        Dividend(date(2026, 3, 1), 0.25),
    )


def test_discrete_dividend_present_value() -> None:
    from math import exp

    schedule = DiscreteDividendSchedule((Dividend(date(2026, 7, 2), 1.0),))
    pv = schedule.present_value(date(2026, 1, 1), date(2027, 1, 1), 0.05)
    t = (date(2026, 7, 2) - date(2026, 1, 1)).days / 365.0
    assert pv == pytest.approx(exp(-0.05 * t))
