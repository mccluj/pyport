from pathlib import Path
import runpy


ROOT = Path(__file__).resolve().parents[1]


def test_examples_execute(capsys) -> None:
    examples = (
        ROOT / "examples" / "01_black_scholes_european.py",
        ROOT / "examples" / "02_crr_european.py",
        ROOT / "examples" / "03_compare_bs_crr.py",
        ROOT / "examples" / "04_crr_discrete_dividends.py",
        ROOT / "examples" / "05_black_scholes_discrete_approximation.py",
    )

    for example in examples:
        runpy.run_path(str(example), run_name="__main__")

    output = capsys.readouterr().out
    assert "Black-Scholes European call:" in output
    assert "CRR European call:" in output
    assert "Difference:" in output
    assert "CRR American call with discrete dividends:" in output
    assert "Escrowed-dividend Black-Scholes European call:" in output
