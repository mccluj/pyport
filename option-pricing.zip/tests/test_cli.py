from option_pricing.cli.main import main


def test_compare_cli(monkeypatch, capsys) -> None:
    monkeypatch.setattr(
        "sys.argv",
        [
            "option-price",
            "compare",
            "--type",
            "call",
            "--spot",
            "100",
            "--strike",
            "100",
            "--valuation-date",
            "2026-01-01",
            "--expiry",
            "2027-01-01",
            "--rate",
            "0.05",
            "--vol",
            "0.20",
            "--yield",
            "0.01",
            "--steps",
            "500",
        ],
    )
    assert main() == 0
    output = capsys.readouterr().out
    assert "black_scholes,european" in output
    assert "crr,european" in output


def test_discrete_dividend_compare_cli(monkeypatch, capsys) -> None:
    monkeypatch.setattr(
        "sys.argv",
        [
            "option-price",
            "compare",
            "--type",
            "call",
            "--spot",
            "100",
            "--strike",
            "100",
            "--valuation-date",
            "2026-01-01",
            "--expiry",
            "2027-01-01",
            "--rate",
            "0.05",
            "--vol",
            "0.20",
            "--dividend",
            "2026-03-15:0.25",
            "--dividend",
            "2026-06-15:0.25",
            "--steps",
            "500",
        ],
    )
    assert main() == 0
    output = capsys.readouterr().out
    assert "black_scholes_escrowed_dividend,european" in output
    assert "crr,european" in output
