from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


SCRIPT = (
    Path(__file__).parents[1]
    / "experiments"
    / "deep_itm_call"
    / "deep_itm_call.py"
)


def _load_experiment_module():
    module_name = "deep_itm_call_experiment"
    spec = importlib.util.spec_from_file_location(module_name, SCRIPT)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def test_default_deep_itm_experiment_builds_comparison_rows() -> None:
    module = _load_experiment_module()
    scenario = module.DeepItmCallScenario(crr_steps=100)
    rows = module.build_rows(scenario)

    assert len(rows) == 6
    assert {row["dividend_case"] for row in rows} == {
        "continuous_yield",
        "quarterly_cash",
    }
    assert {row["style"] for row in rows} == {"european", "american"}
    assert all("price" in row for row in rows)
    assert all("american_premium" in row for row in rows)


def test_default_discrete_american_row_exposes_exercise_diagnostics() -> None:
    module = _load_experiment_module()
    scenario = module.DeepItmCallScenario(crr_steps=100)
    rows = module.build_rows(scenario)

    discrete_american = next(
        row
        for row in rows
        if row["dividend_case"] == "quarterly_cash"
        and row["style"] == "american"
    )
    assert isinstance(discrete_american["exercise_detail"], str)
