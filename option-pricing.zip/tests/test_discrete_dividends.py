from datetime import date

import pytest

from option_pricing.engines import (
    BlackScholesEngine,
    CRRConfig,
    CRREngine,
    EscrowedDividendBlackScholesEngine,
    UnsupportedPricingRequest,
)
from option_pricing.instruments import ExerciseStyle, Option, OptionType
from option_pricing.market import (
    ContinuousDividendYield,
    DiscreteDividendSchedule,
    Dividend,
    MarketData,
)


def _quarterly_schedule() -> DiscreteDividendSchedule:
    return DiscreteDividendSchedule(
        (
            Dividend(date(2026, 3, 15), 0.25),
            Dividend(date(2026, 6, 15), 0.25),
            Dividend(date(2026, 9, 15), 0.25),
            Dividend(date(2026, 12, 15), 0.25),
        )
    )


def test_plain_black_scholes_still_rejects_discrete_dividends() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, _quarterly_schedule())
    with pytest.raises(UnsupportedPricingRequest):
        BlackScholesEngine().price(option, market)


def test_escrowed_black_scholes_requires_discrete_schedule() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    market = MarketData(
        date(2026, 1, 1),
        100.0,
        0.05,
        0.20,
        ContinuousDividendYield(0.01),
    )
    with pytest.raises(UnsupportedPricingRequest):
        EscrowedDividendBlackScholesEngine().price(option, market)


def test_escrowed_black_scholes_rejects_american() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.AMERICAN, 100.0, date(2027, 1, 1))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, _quarterly_schedule())
    with pytest.raises(UnsupportedPricingRequest):
        EscrowedDividendBlackScholesEngine().price(option, market)


def test_escrowed_black_scholes_reports_adjustment() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, _quarterly_schedule())
    result = EscrowedDividendBlackScholesEngine().price(option, market)

    assert result.diagnostics is not None
    assert result.diagnostics["dividend_method"] == "escrowed"
    assert result.diagnostics["dividend_present_value"] > 0.0
    assert result.diagnostics["adjusted_spot"] < market.spot


def test_crr_european_discrete_converges_to_escrowed_bs() -> None:
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, _quarterly_schedule())

    baseline = EscrowedDividendBlackScholesEngine().price(option, market).price
    crr = CRREngine(CRRConfig(2000)).price(option, market).price
    assert crr == pytest.approx(baseline, abs=0.003)


def test_crr_american_discrete_is_not_less_than_european() -> None:
    schedule = DiscreteDividendSchedule((Dividend(date(2026, 7, 1), 10.0),))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, schedule)
    european = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 50.0, date(2027, 1, 1))
    american = Option(OptionType.CALL, ExerciseStyle.AMERICAN, 50.0, date(2027, 1, 1))
    engine = CRREngine(CRRConfig(1000))

    european_price = engine.price(european, market).price
    american_result = engine.price(american, market)
    assert american_result.price > european_price
    assert american_result.diagnostics is not None
    assert american_result.diagnostics["early_exercise_steps"]


def test_crr_empty_discrete_schedule_matches_zero_yield_crr() -> None:
    option = Option(OptionType.PUT, ExerciseStyle.AMERICAN, 100.0, date(2027, 1, 1))
    discrete_market = MarketData(
        date(2026, 1, 1),
        90.0,
        0.05,
        0.20,
        DiscreteDividendSchedule(()),
    )
    yield_market = MarketData(
        date(2026, 1, 1),
        90.0,
        0.05,
        0.20,
        ContinuousDividendYield(0.0),
    )
    engine = CRREngine(CRRConfig(500))
    assert engine.price(option, discrete_market).price == pytest.approx(
        engine.price(option, yield_market).price,
        abs=1e-12,
    )


def test_discrete_dividend_adjustment_requires_positive_risky_spot() -> None:
    schedule = DiscreteDividendSchedule((Dividend(date(2026, 7, 1), 200.0),))
    market = MarketData(date(2026, 1, 1), 100.0, 0.05, 0.20, schedule)
    option = Option(OptionType.CALL, ExerciseStyle.EUROPEAN, 100.0, date(2027, 1, 1))

    with pytest.raises(ValueError, match="less than spot"):
        EscrowedDividendBlackScholesEngine().price(option, market)
    with pytest.raises(ValueError, match="less than spot"):
        CRREngine(CRRConfig(500)).price(option, market)
