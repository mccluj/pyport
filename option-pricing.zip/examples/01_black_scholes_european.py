from datetime import date

from option_pricing import (
    ContinuousDividendYield,
    ExerciseStyle,
    MarketData,
    Option,
    OptionType,
)
from option_pricing.engines import BlackScholesEngine


def main() -> None:
    option = Option(
        option_type=OptionType.CALL,
        exercise_style=ExerciseStyle.EUROPEAN,
        strike=100.0,
        expiry=date(2027, 9, 18),
    )
    market = MarketData(
        valuation_date=date(2026, 9, 18),
        spot=100.0,
        risk_free_rate=0.05,
        volatility=0.20,
        dividends=ContinuousDividendYield(0.01),
    )

    result = BlackScholesEngine().price(option, market)
    print(f"Black-Scholes European call: {result.price:.6f}")


if __name__ == "__main__":
    main()
