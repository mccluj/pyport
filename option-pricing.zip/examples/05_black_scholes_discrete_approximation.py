from datetime import date

from option_pricing.engines import EscrowedDividendBlackScholesEngine
from option_pricing.instruments import ExerciseStyle, Option, OptionType
from option_pricing.market import DiscreteDividendSchedule, Dividend, MarketData


option = Option(
    option_type=OptionType.CALL,
    exercise_style=ExerciseStyle.EUROPEAN,
    strike=100.0,
    expiry=date(2027, 1, 1),
)
market = MarketData(
    valuation_date=date(2026, 1, 1),
    spot=100.0,
    risk_free_rate=0.05,
    volatility=0.20,
    dividends=DiscreteDividendSchedule(
        (
            Dividend(date(2026, 3, 15), 0.25),
            Dividend(date(2026, 6, 15), 0.25),
            Dividend(date(2026, 9, 15), 0.25),
            Dividend(date(2026, 12, 15), 0.25),
        )
    ),
)

result = EscrowedDividendBlackScholesEngine().price(option, market)
print(f"Escrowed-dividend Black-Scholes European call: {result.price:.6f}")
