from datetime import date

from option_pricing import (
    ContinuousDividendYield,
    ExerciseStyle,
    MarketData,
    Option,
    OptionType,
)
from option_pricing.engines import BlackScholesEngine, CRRConfig, CRREngine


def main() -> None:
    option = Option(
        option_type=OptionType.CALL,
        exercise_style=ExerciseStyle.EUROPEAN,
        strike=100.0,
        expiry=date(2027, 9, 18),
    )
    market = MarketData(
        valuation_date=date(2026, 9, 18),
        spot=100.0,
        risk_free_rate=0.05,
        volatility=0.20,
        dividends=ContinuousDividendYield(0.01),
    )

    bs = BlackScholesEngine().price(option, market)
    crr = CRREngine(CRRConfig(steps=1000)).price(option, market)

    print(f"Black-Scholes: {bs.price:.6f}")
    print(f"CRR:           {crr.price:.6f}")
    print(f"Difference:    {crr.price - bs.price:+.6f}")


if __name__ == "__main__":
    main()
